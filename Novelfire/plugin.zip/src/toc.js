load('config.js');

function execute(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('utf-8');
        var chapnum = doc.select("div.header-stats span strong").Text()
        const data = [];
        for (let i = 0;i < chapnum; i++) {
            data.push({
                name: "chapter " + i,
                url: url + "/chapter-" + i,
                host: "https://novelfire.net"
            })
        }
        return Response.success(data);
    }
    return null;
}